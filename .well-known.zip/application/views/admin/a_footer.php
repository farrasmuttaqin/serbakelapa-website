
<!-- login area end -->

<!-- jquery latest version -->
<script src="<?php echo base_url(); ?>adminassets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="<?php echo base_url(); ?>adminassets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/metisMenu.min.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/jquery.slicknav.min.js"></script>

<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
    
<!-- others plugins -->
<script src="<?php echo base_url(); ?>adminassets/js/plugins.js"></script>
<script src="<?php echo base_url(); ?>adminassets/js/scripts.js"></script>

